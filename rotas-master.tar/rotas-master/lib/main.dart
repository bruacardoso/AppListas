import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_application_1/cadastro.dart';
import 'package:flutter_application_1/login.dart';
import 'package:flutter_application_1/my_home_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      routes: {
        Navigator.defaultRouteName: (context) =>
            const MyHomePage(title: 'Flutter Demo Home Page'),
        TelaDeCadastro.routeName: (context) => TelaDeCadastro(),
        TelaDeLogin.routeName: (context) => TelaDeLogin(),
      },
    );
  }
}
